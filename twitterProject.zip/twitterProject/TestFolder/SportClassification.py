"""
File to create a machine learning model that distinguishes between sports given a tweet

Data Cleaning/Editing
Using context annotations determine which sport the tweet is referencing
Append information to dictionary
Use this info to train model



"""
