"""
File to test filtered topic tweets
Randomly selects tweets
Returned 7 tweets when count=5

problem currently only writes last tweet. Probably because it overwrites the old ones each iter.
"""
# This will import the Twarc2 client and expansions class from twarc library and also the json
# library
from twarc import Twarc2, expansions
import csv

# This is where you initialize the client with your own bearer token (replace the XXXXX with your
# own bearer token)
client = Twarc2(bearer_token="AAAAAAAAAAAAAAAAAAAAAKmpkgEAAAAACFo9cY8tDP%2BsUvRS7zbOKpR0zf8"
                             "%3DggxVi0JaBmC7DHc6jI3DWH6OV10OnECBJEyLDTpRmRSwaljXQp")


def main():

    # Define header
    header = "1"

    # Remove existing rules
    existing_rules = client.get_stream_rules()
    if 'data' in existing_rules and len(existing_rules['data']) > 0:
        rule_ids = [rule['id'] for rule in existing_rules['data']]
        client.delete_stream_rule_ids(rule_ids)

    # Add new rules
    # Replace the rules below with the ones that you want to add as discussed in module 5
    new_rules = [
        {"value": "World Cup OR World Cup 2022 lang:en", "tag": "worldcup-related-tweets"},
        {"value": "WCQatar OR Qatar2022 OR WC2022", "tag": "worldcup-related-tweets"}
    ]
    added_rules = client.add_stream_rules(rules=new_rules)

    # Connect to the filtered stream
    for count, result in enumerate(client.stream()):
        # The Twitter API v2 returns the Tweet information and the user, media etc.  separately
        # so we use expansions.flatten to get all the information in a single JSON
        tweet = expansions.flatten(result)  # flattens each result
        # Here we are printing the full Tweet object JSON to the console

        with open('countries.csv', 'w', encoding='UTF8') as f:
            writer = csv.writer(f)

            # write the header
            writer.writerow(header)

            # write the data
            writer.writerow(tweet)

        # Replace with the desired number of Tweets
        if count > 2:
            break

    # Delete the rules once you have collected the desired number of Tweets
    rule_ids = [rule['id'] for rule in added_rules['data']]
    client.delete_stream_rule_ids(rule_ids)


# Need to clean json file s.t. after each dictionary object insert comma remove brackets signifying
# end of dictionary on both sides
if __name__ == "__main__":
    main()
